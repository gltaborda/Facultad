package fiuba.algo3.tp1;

public class PaqueteNoExisteError extends RuntimeException {

}
