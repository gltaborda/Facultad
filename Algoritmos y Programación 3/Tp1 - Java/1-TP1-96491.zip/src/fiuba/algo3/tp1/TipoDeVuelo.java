package fiuba.algo3.tp1;

public interface TipoDeVuelo {

    public double obtenerCosto(Ciudad origen, Ciudad destino);

}
